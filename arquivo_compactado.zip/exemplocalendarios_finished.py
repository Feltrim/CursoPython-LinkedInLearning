#
# Arquivo com exemplos de uso de calendários
#


import calendar

def ImprimeMes ():
    for mes in calendar.month_name:
        print (mes)

    for dia in calendar.day_name:
        print (dia)
        
ImprimeMes()